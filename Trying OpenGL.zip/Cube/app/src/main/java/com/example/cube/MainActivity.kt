package com.ssaurel.opengltuts;

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import com.example.cube.ui.theme.CubeTheme

public class MainActivity extends AppCompatActivity{
    private OpenGLView openGLView;

    @Override
    protected void onCreate(Bundle savedInstance State){
        super.onCreate(savedInstanceState);
        setContentView(R,layout.activity.main);
        openGLView = (OpenGLView) findViewByID(id.openGLView);
    }

    @Override
    protected void onResume() {
        super.onResume();
        openGLView.onResume();
    }

    @Override
    protected void onPause() {
        super.onPause();
        openGLView.onPause();
    }
}